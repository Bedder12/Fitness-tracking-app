package app;

import java.io.FileNotFoundException;

import javax.swing.SwingUtilities;

import controller.Controller;
import model.User;
import view.LogginPanel;
import view.MainFrame;

public class MainApp {
	public static void main(String[] args) throws FileNotFoundException {
		Controller controller = new Controller();
		SwingUtilities.invokeLater(() -> new MainFrame(controller));
	}
}
