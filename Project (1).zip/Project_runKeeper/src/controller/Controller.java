package controller;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import dao.DAO;
import model.Activity;
import model.Statistics;
import model.TrackPoint;
import model.User;
import view.mainPanel.MainPanel;

public class Controller {
    private DAO dao;
    private List<TrackPoint> points;
    private Statistics stats;
    private User currUser;
    private Activity currActivity;

	public Controller() throws FileNotFoundException{
		dao = new DAO(this);
    }
	
	public void save() {
		dao.saveFile();
	}
	
	public void loadFile() {
		dao.loadFile();
	}
	
	public List<TrackPoint> getTrackPointList() {
		return currActivity.getActivity();
	}
	
	public User getCurrentUser() {
		return currUser;
	}
	
	public void setCurrentUser(User user) {
		this.currUser = user;
	}
	
	public void setCurrentUser(String name, int ålder, double vikt, double puls) {
		try {
			User user = new User(name, ålder, vikt, puls);
			this.currUser = user;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void setFile(String textpath, String name) throws FileNotFoundException {
		// skapa ny dao i konstruktorn i controller. 
		dao.scanText(textpath, name);
	}
	
//	public void ChangeAktivityName(String aktivityname) {
//		currActivity.setName(aktivityname);
//	}
   

    public void createTrackPoint(List<String> line, String name) {
		// varje line läggs i en sträng och skapar ett trackpoint objekt.
    	points = new ArrayList<TrackPoint>();
		for (String s : line) {
			TrackPoint tp = new TrackPoint(s);
			points.add((TrackPoint) tp);
		}
		createActivity(points, name);
		createStatics(points);
    }
  
	// skapar ny statistik med lista av trackpoints.
	public void createStatics(List<TrackPoint> tp) {
		stats = new Statistics(points); 
	}
	
	// Skapar ny aktivitet med lista av trackpoints.
	public void createActivity(List<TrackPoint> tp, String name){ 
		Activity activity = new Activity(points, name, currUser);
	}
	
	public void setCurrentActivity(String activity) {
		currActivity = currUser.getMap().get(activity);
	}
	
	public Activity getCurrentActivity(){
		return currActivity;
	}
	
	public List<TrackPoint> getActivity(){
		return currActivity.getActivity();
	}
	
	public Collection<Activity> getActivites(){
		return currUser.getActivities();
	}
	
	public String getStartTime() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			return stats.startTime();
		}
		else
		return "00:00:00";
	}
	
	public String getEndTime() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			return stats.endTime();
		}
		else
		return "00:00:00";
	}
	
	public String getTotalDistance() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String totalDistance = String.format("%,.2f", stats.totalDistance());
			return totalDistance;
		}
		else
		return "0.0";
	}
	
	public String getAveragePulse() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String avgPulse = String.format("%,.2f", stats.averagePulse());
			return avgPulse;
		}
		else
		return "0.0";
	}
	// behövs max- & min metoderna???? 
	public String getMinPulse() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String minPulse = String.format("%,.2f", stats.minPulse());
			return minPulse;
		}
		else
		return "0.0";
	}
	
	public String getMaxPulse() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String maxPulse = String.format("%,.2f", stats.maxPulse());
			return maxPulse;
		}
		else
		return "0.0";
	}
	
	public String getAverageSpeed() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String avgSpeed = String.format("%,.2f", stats.averageSpeed());
			return avgSpeed;
		}
		else
		return "0.0";
	}
	
	public String getMinSpeed() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String minSpeed = String.format("%,.2f", stats.minSpeed());
			return minSpeed;
		}
		else
		return "0.0";
	}
	
	public String getMaxSpeed() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String maxSpeed = String.format("%,.2f", stats.maxSpeed());
			return maxSpeed;
		}
		else
		return "0.0";
	}
	
	public String getAverageCadence() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String avgCadence = String.format("%,.2f", stats.averageCadence());
			return avgCadence;
		}
		else
		return "0.0";
	}
	
	public String getMinCadence() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String minCadence = String.format("%,.2f", stats.minCadence());
			return minCadence;
		}
		else
		return "0.0";
	}
	
	public String getMaxCadence() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			String maxCadence = String.format("%,.2f", stats.maxCadence());
			return maxCadence;
		}
		else
		return "0.0";
	}
	
	public void getElapsedTime() {
		if (currActivity != null) {
			stats = new Statistics(currActivity.getActivity());
			stats.elapsedTime();
		}
	}
}
