package dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import controller.Controller;
import model.User;

public class DAO {
	private File test;
	private Controller controller;
	
	public DAO(Controller controller) throws FileNotFoundException {
		this.controller = controller;
	}
	
	public void saveFile(){
		try {
			this.test = new File("C:\\Users\\jonas\\OneDrive\\Skrivbord\\projektarbete\\Test_" + controller.getCurrentUser().getName() + ".txt");
			FileOutputStream fileOut = new FileOutputStream(test);
			ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(controller.getCurrentUser());
			objOut.close();
			fileOut.close();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void loadFile() {

		if (controller.getCurrentUser() != null) {
			try {
				this.test = new File("C:\\Users\\jonas\\OneDrive\\Skrivbord\\projektarbete\\Test_" + controller.getCurrentUser().getName() + ".txt");
				FileInputStream fileIn = new FileInputStream(test);
				ObjectInputStream objIn = new ObjectInputStream(fileIn);
				User currUser = null;
				currUser = (User) objIn.readObject();
				fileIn.close();
				objIn.close();
				
				controller.setCurrentUser(currUser);
			}catch (IOException | ClassNotFoundException | NullPointerException e) {
				e.printStackTrace();
			}
		}
	}

	public void scanText(String file, String name) throws FileNotFoundException{
		File activityFile = new File(file);
    	Scanner scanner = new Scanner(activityFile);
    	scanner.nextLine(); // läser in första raden som ej behövs
    	
		// skapar en lista för att spara alla rader.
    	List<String> linesList = new ArrayList<String>();
    	while(scanner.hasNext()) {
    		linesList.add(scanner.nextLine());
    	}

		controller.createTrackPoint(linesList, name);
    	scanner.close();
    }
}
