package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Activity implements Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private String date;
	private User userName;
	// attribut av userobjekt
	private List<TrackPoint> trackPoints = new ArrayList<TrackPoint>();
	
	public Activity(List<TrackPoint> list, String name, User currUser){
		trackPoints.addAll(list);
		this.date = list.get(0).getDate();
		this.name = name;
		this.userName = currUser;
		userName.addActivity(this);
	}
	
	public List<TrackPoint> getActivity(){
		return trackPoints;
	}
	
	public String getUserName() {
		return userName.toString();
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getDate() {
		return this.date;
	}
	
//	public void setName(String name) {
//		// ska sätta namn på trackpointlista så de hör ihop.
//		this.name = name;
//		System.out.println(name);
//	}
	
	@Override
	public String toString() {
		return name + " " + date;
	}

}
