package model;

public interface DataFetcher {
	public double fetch (TrackPoint trackpoint);
}
