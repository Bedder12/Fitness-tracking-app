package model;

import java.util.ArrayList;
import java.util.List;

public class Statistics{

	private List<TrackPoint> trackPoints;
	private TrackPoint firstLine;
	private TrackPoint lastLine;
	private double highest;
	private double temp;
	private double lowest;
	
	public Statistics(List<TrackPoint> list) {
		this.trackPoints = new ArrayList(list);
	}
	
	// Lägger alla longitude värden i en array.
	public double[] longitude() {
		double[] longitude = new double[trackPoints.size()];
		for (int i = 0; i < trackPoints.size(); i++) {
			longitude[i] = trackPoints.get(i).getLongitude();
		}
		return longitude;
	}
	
	// Lägger alla latitude värden i en array.
	public double[] latitude() {
		double[] lat = new double[trackPoints.size()];
		for (int i = 0; i < trackPoints.size(); i++) {
			lat[i] = trackPoints.get(i).getLatitude();
		}
		return lat;
	}
	 
	// Lägger alla altitude värden i en array.
	public double[] altitude() {
		double[] alt = new double[trackPoints.size()];
		for (int i = 0; i < trackPoints.size(); i++) {
			alt[i] = trackPoints.get(i).getAltitude();
		}
		return alt;
	}
	
	// beräknar hur långt tid aktiviteten tog i h:m:s
	public void elapsedTime() {
		lastLine = trackPoints.get(trackPoints.size()-1);
		int seconds = lastLine.getElapsedTime() % 60;
		int hour = lastLine.getElapsedTime() / 60;
		int minute = hour % 60;
		hour = hour / 60;
		System.out.println(lastLine.getElapsedTime() + "s tid");
		System.out.println(hour + ":" + minute + ":" + seconds);
	}
	
	public double totalDistance() {
		// Beräkna totala distansen, slutDistansen - startDistansen = totalDistansen. 
		firstLine = trackPoints.get(0);
		double startDistance = firstLine.getDistance();
		lastLine = trackPoints.get(trackPoints.size() - 1);
		double endDistance = lastLine.getDistance();
		double totalDistance = endDistance - startDistance;
		System.out.println(totalDistance + " total distance");
		return totalDistance;
	}

	public String startTime() {
		firstLine = trackPoints.get(0);
		String start = firstLine.getTime();
		System.out.println(start + " startTime");
		return start;
	}

	public String endTime() {
		// om man bara behöver sista tiden.
		lastLine = trackPoints.get(trackPoints.size() - 1);
		String end = lastLine.getTime();
		System.out.println(end + " endTime");
		return end;
	}
	
	public double averagePulse() {
		double avPulse = 0.0;
		temp = 0.0;
		for(TrackPoint t : trackPoints) {
			temp += t.getHeartRate();
		}
		avPulse = temp / trackPoints.size();
		System.out.println(avPulse + " average pulse");
		return avPulse;
	}

	public double minPulse() {
		temp = 0.0;
		lowest = Integer.MAX_VALUE;
		for(TrackPoint t : trackPoints) {
			temp = t.getHeartRate();
			if (temp < lowest) {
				lowest = temp;
			}
		}
		System.out.println(lowest + " lowest pulse");
		return lowest;
	}

	public double maxPulse() {
		temp = 0.0;
		highest = 0.0;
		for(TrackPoint t : trackPoints) {
			temp = t.getHeartRate();
			if (temp > highest) {
				highest = temp;
			}
		}
		System.out.println(highest + " highest pulse");
		return highest;
	}

	public double averageSpeed() {
		double avSpeed = 0.0;
		temp = 0.0;
		for(TrackPoint t : trackPoints) {
			temp += t.getSpeed();
		}
		avSpeed = temp / trackPoints.size();
		System.out.println(avSpeed + " average speed");
		return avSpeed;
	}

	public double minSpeed() {
		temp = 0.0;
		lowest = Integer.MAX_VALUE;
		for(TrackPoint t : trackPoints) {
			temp = t.getSpeed();
			if (temp < lowest) {
				lowest = temp;
			}
		}
		System.out.println(lowest + " lowest speed");
		return lowest;
	}

	public double maxSpeed() {
		temp = 0.0;
		highest = 0.0;
		for(TrackPoint t : trackPoints) {
			temp = t.getSpeed();
			if (temp > highest) {
				highest = temp;
			}
		}
		System.out.println(highest + " highest speed");
		return highest;
	}

	public double averageCadence() {
		double avCadence = 0.0;
		temp = 0.0;
		for(TrackPoint t : trackPoints) {
			temp += t.getCadence();
		}
		avCadence = temp / trackPoints.size();
		System.out.println(avCadence + " average cadence");
		return avCadence;
	}

	public double minCadence() {
		lowest = Integer.MAX_VALUE;
		temp = 0.0;
		for(TrackPoint t : trackPoints) {
			temp = t.getCadence();
			if (temp < lowest) {
				lowest = temp;
			}
		}
		System.out.println(lowest + " lowest cadence");
		return lowest;
	}

	public double maxCadence() {
		temp = 0.0;
		highest = 0.0;
		for(TrackPoint t : trackPoints) {
			temp = t.getCadence();
			if (temp > highest) {
				highest = temp;
			}
		}
		System.out.println(highest + " highest cadence");
		return highest;
	}

}
