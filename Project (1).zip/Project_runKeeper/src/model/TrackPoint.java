package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TrackPoint implements Serializable{

	private static final long serialVersionUID = 1L;
	private String date;
	private String time;
	private int elapsedTime;
	private double longitude;
	private double latitude;
	private double altitude;
	private double distance;
	private double heartRate;
	private double speed;
	private double cadence;
	
	public TrackPoint(String attribute) {
        String temp = attribute;
        for (int i = 0; i < temp.length(); i++){
            temp = temp.replace(",", ".");
        }
        String[] activityAttributes = temp.split(";");
		
		
        this.date = activityAttributes[0];
        this.time = activityAttributes[1];
        this.elapsedTime = Integer.parseInt(activityAttributes[2]);
        this.longitude = Double.parseDouble(activityAttributes[3]);
        this.latitude = Double.parseDouble(activityAttributes[4]);
        this.altitude = Double.parseDouble(activityAttributes[5]);
        this.distance = Double.parseDouble(activityAttributes[6]);
        this.heartRate = Double.parseDouble(activityAttributes[7]);
        this.speed = Double.parseDouble(activityAttributes[8]);
        this.cadence = Double.parseDouble(activityAttributes[9]);
	}

	public String getDate() {
		return date;
	}

	public String getTime() {
		return time;
	}

	public int getElapsedTime() {
		return elapsedTime;
	}

	public double getLongitude() {
		return longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public double getAltitude() {
		return altitude;
	}

	public double getDistance() {
		return distance;
	}

	public double getHeartRate() {
		return heartRate;
	}

	public double getSpeed() {
		return speed;
	}

	public double getCadence() {
		return cadence;
	}
	
	@Override
	public String toString() {
		return getDistance() + "";
	}
}
