package model;

import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import controller.Controller;

public class User implements Serializable{

	private static final long serialVersionUID = 1L;
	private String userName;
	private int age;
	private double weight;
	private double maxPulse;
	private Map<String, Activity> activities = new HashMap<String, Activity>();
	
	public User(String userName, int age, double weight, double maxPulse) throws FileNotFoundException {
		this.userName = userName;
		this.age = age;
		this.weight = weight;
		this.maxPulse = maxPulse;
	}
	
	public String getName() {
		return userName;
	}
	
	public int getAge() {
		return age;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public double getMaxPulse() {
		return maxPulse;
	}
	
	public void addActivity(Activity activity) {
		activities.put(activity.getName() + " " + activity.getDate(), activity);
		System.out.println(getActivities());
	}
	public Collection<Activity> getActivities(){
		return activities.values();
	}
	public String toString() {
		return userName;
	}

	public Map<String, Activity> getMap() {
		return activities;
	}
}
