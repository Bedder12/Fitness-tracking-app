package view;

import java.awt.Color;
import java.io.FileNotFoundException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import controller.Controller;
import model.User;

public class LogginPanel extends JPanel{
	private JLabel label, header;
	private JComboBox username;
	private JButton button;
	private MainFrame mainFrame;
	private String[] konton = {"Josephine", "Jonas", "Fabian"};
	private Controller controller;
	
	public LogginPanel(MainFrame mainFrame,Controller controller) {
		this.mainFrame = mainFrame;
		this.controller = controller;
		setLayout(null);
		
		// Header 
		header = new JLabel("<html><h1><strong><i>Gizmo2020</i></strong></h1><hr></html>");
		header.setBounds(550,100,200,30);
		add(header);
		
		// Username label constructor
		label = new JLabel("Username:");
		label.setBounds(550, 250, 70, 20);
		add(label);
		
		// Username TextField constructor
		username = new JComboBox(konton);
		username.setBounds(550, 300, 193, 28);
		username.setSelectedIndex(0);
//		username.addActionListener(e -> setUser());
		add(username);
		
		// Button constructor
		button = new JButton("Login");
		button.setBounds(550, 350, 90, 25);
		button.setForeground(Color.WHITE);
		button.setBackground(Color.BLACK);
		button.addActionListener(e -> setUser());
		add(button);
	}
	
//	// Byter från loggin till mainPanel
//	public void changePanel() {
//
//
//	}
	
	public void setUser() {
		this.setVisible(false);
		String user = (String) this.username.getSelectedItem();
		if (user == "Josephine") {
			controller.setCurrentUser(user, 27, 65, 178);
		}else if (user == "Jonas") {
			controller.setCurrentUser(user, 27, 86, 200);
		}else {
			controller.setCurrentUser(user, 21, 78, 180);
		}
		mainFrame.createMainPanel();
	}
}
