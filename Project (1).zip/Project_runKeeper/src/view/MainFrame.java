package view;

import java.awt.CardLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

import controller.Controller;
import view.mainPanel.MainPanel;

public class MainFrame extends JFrame{
	private Controller controller;
	private MainPanel mainPanel;
	private LogginPanel logginPanel;
	
	public MainFrame(Controller controller) {
		super("Gizmo2020");
		this.controller = controller;
		logginPanel = new LogginPanel(this, controller);
		setSize(800,600);
		setExtendedState(MAXIMIZED_BOTH);
		add(logginPanel);
		setVisible(true);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				if (controller.getCurrentUser() != null) {
					controller.save();
				}
			}
		});
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public void createMainPanel() {
		mainPanel = new MainPanel(controller);	
		this.add(mainPanel);
		controller.loadFile();
		mainPanel.updateList();
	}
}
