package view.mainPanel;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.Controller;

public class DataView extends JPanel{
	private Controller controller;
	
	private JPanel dist = new JPanel();
	private JLabel distance = new JLabel("Distans");
	private JLabel currDist;
	
	private JPanel start = new JPanel();
	private JLabel startTime = new JLabel("Starttid");
	private JLabel currStartTime;
	
	private JPanel end = new JPanel();
	private JLabel endTime = new JLabel("Sluttid");
	private JLabel currEndTime;
	
	private JPanel spe = new JPanel();
	private JLabel speed = new JLabel("Medelhastighet");
	private JLabel currSpeed;
	private JLabel minMaxSpeed = new JLabel();
	
	private JPanel cad = new JPanel();
	private JLabel cadence = new JLabel("Medelkadens");
	private JLabel currCadence;
	private JLabel minMaxCadence = new JLabel();
	
	private JPanel pul = new JPanel();
	private JLabel pulse = new JLabel("Medelpuls");
	private JLabel currPulse;
	private JLabel minMaxPulse = new JLabel();
	
	
	GridBagConstraints gbc = new GridBagConstraints();
	Font mainContent = new Font("Sans-serif", Font.BOLD, 30);
	
	public DataView(Controller controller) {
		this.controller = controller;
		setBackground(Color.PINK);
		setLayout(new GridLayout(2,3));
		
		// Fylla cell 0,0 i GridLayouten
		dist.setLayout(new GridBagLayout());
		gbc.gridx = 0;
		gbc.gridy = 0;
		dist.add(distance, gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		// Ändra så att texten i JLabel hämtas från vald aktivitet
		currDist = new JLabel(controller.getTotalDistance());
		currDist.setFont(mainContent);
		dist.add(currDist, gbc);
		add(dist, gbc);
		
		// Fylla cell 0,1 i GridLayouten
		start.setLayout(new GridBagLayout());
		gbc.gridx = 0;
		gbc.gridy = 0;
		start.add(startTime, gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		// Ändra så att texten i JLabel hämtas från vald aktivitet
		currStartTime = new JLabel("17:27:41");
		currStartTime.setFont(mainContent);
		start.add(currStartTime, gbc);
		add(start);		
		
		// Fylla cell 0,2 i GridLayouten
		end.setLayout(new GridBagLayout());
		gbc.gridx = 0;
		gbc.gridy = 0;
		end.add(endTime, gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		// Ändra så att texten i JLabel hämtas från vald aktivitet
		currEndTime = new JLabel("18:13:24");
		currEndTime.setFont(mainContent);
		end.add(currEndTime, gbc);
		add(end);		
		
		// Fylla i cell 1,0 i GridLayouten
		spe.setLayout(new GridBagLayout());
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		spe.add(speed, gbc);
//		gbc.gridx = 0;
//		gbc.gridy = 1;
//		spe.add(medel, gbc);
		gbc.gridx = 2;
		gbc.gridy = 2;
		// Ändra så att texten i JLabel hämtas från vald aktivitet
		currSpeed = new JLabel("6.03 min/sek");
		currSpeed.setFont(mainContent);
		spe.add(currSpeed, gbc);
		gbc.gridx = 2;
		gbc.gridy = 6;
//		gbc.gridwidth = 3;
		minMaxSpeed.setText("Min: " + controller.getMinSpeed() + "    Max: " + controller.getMaxSpeed());
		spe.add(minMaxSpeed, gbc);
//		gbc.gridx = 3;
//		gbc.gridy = 6;
//		gbc.gridwidth = 3;
//		max.setText("Max: " + controller.getMaxSpeed());
//		spe.add(max, gbc);
		add(spe);		

		// Fylla i cell 1,1 i GridLayout
		cad.setLayout(new GridBagLayout());
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		cad.add(cadence, gbc);
		gbc.gridx = 2;
		gbc.gridy = 2;
		// Ändra så att texten i JLabel hämtas från vald aktivitet
		currCadence = new JLabel("4 steg/sek");
		currCadence.setFont(mainContent);
		cad.add(currCadence, gbc);
		gbc.gridx = 2;
		gbc.gridy = 6;
		minMaxCadence.setText("Min: " + controller.getMinCadence() + "    Max: " + controller.getMaxCadence());
		cad.add(minMaxCadence, gbc);
		add(cad);
		
		//Fylla i cell 1,2 i GridLayout
		pul.setLayout(new GridBagLayout());
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		pul.add(pulse, gbc);
		gbc.gridx = 2;
		gbc.gridy = 2;
		// Ändra så att texten i JLabel hämtas från vald aktivitet
		currPulse = new JLabel("120 slag/min");
		currPulse.setFont(mainContent);
		pul.add(currPulse, gbc);
		gbc.gridx = 2;
		gbc.gridy = 6;
		minMaxPulse.setText("Min: " + controller.getMinPulse() + "    Max: " + controller.getMaxPulse());
		pul.add(minMaxPulse, gbc);
		add(pul);
	}
	public void updateView() {
		currDist.setText(controller.getTotalDistance());
		currStartTime.setText(controller.getStartTime());
		currEndTime.setText(controller.getEndTime());
		currSpeed.setText(controller.getAverageSpeed() + " min/km");
		minMaxSpeed.setText("Min: " + controller.getMinSpeed() + "    Max: " + controller.getMaxSpeed());
		currCadence.setText(controller.getAverageCadence());
		minMaxCadence.setText("Min: " + controller.getMinCadence() + "    Max: " + controller.getMaxCadence());		
		currPulse.setText(controller.getAveragePulse());
		minMaxPulse.setText("Min: " + controller.getMinPulse() + "    Max: " + controller.getMaxPulse());
	}
	
}
