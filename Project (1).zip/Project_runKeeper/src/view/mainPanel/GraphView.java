package view.mainPanel;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.util.Iterator;

import javax.swing.JPanel;

import controller.Controller;
import model.TrackPoint;
import view.plot.PlotView;

public class GraphView extends JPanel{
	private PlotView plotHr;
	private PlotView plotSpeed;
	private PlotView PlotCadence;
	private Controller controller;
	
	public GraphView(Controller controller) {
		this.controller = controller;
		setLayout(new GridLayout(3,1));

		// ritar ut den sistnämnda add(plotview), fixa med trådar så att alla kan ritas?
		add(plotHr = new PlotView("Puls", controller, tp -> tp.getHeartRate()));
		add(plotSpeed = new PlotView("Hastighet", controller, tp -> tp.getSpeed()));
		add(PlotCadence = new PlotView("Altitude", controller, tp -> tp.getAltitude()));
//		add(plotview = new PlotView("Distans", controller, tp -> tp.getDistance()));
		setBackground(Color.WHITE);	
	}
	
	public void updatePlot() {
		plotHr.repaint();
		plotSpeed.repaint();
		PlotCadence.repaint();
	}

	



}
