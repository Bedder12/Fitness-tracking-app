package view.mainPanel;

import java.awt.GridLayout;

import javax.swing.JPanel;

import controller.Controller;

public class MainPanel extends JPanel{
	private Controller controller;
	private UserView userView;
	private DataView dataView;
	private MapView mapView;
	private GraphView graphView;
	
	public MainPanel(Controller controller) {
		this.controller = controller;
		dataView = new DataView(controller);
		graphView = new GraphView(controller);
		mapView = new MapView(controller);
		userView = new UserView(controller,dataView, graphView, mapView);

		this.setLayout(new GridLayout(2,2));
		add(userView);
		add(dataView);
		add(mapView);
		add(graphView);
	}
	
	public void updateList() {
		userView.updateList();
	}
}
