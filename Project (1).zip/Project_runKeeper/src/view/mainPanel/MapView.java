package view.mainPanel;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JPanel;

import controller.Controller;
import view.plot.MapPlotView;

public class MapView extends JPanel{
	private Controller controller;
	private MapPlotView mapPlotView;
	
	public MapView(Controller controller) {
		this.controller = controller;
		setLayout(new GridLayout(1,1));
		mapPlotView = new MapPlotView(controller);
		setBackground(Color.ORANGE);	
		add(mapPlotView);
	}
	
	public void updateMap() {
		mapPlotView.repaint();
	}
}
