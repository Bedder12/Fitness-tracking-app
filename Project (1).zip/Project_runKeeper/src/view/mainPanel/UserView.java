package view.mainPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import controller.Controller;

public class UserView extends JPanel{
	private Controller controller;
	// Panel som visa info om användaren
	private JPanel userInfo = new JPanel();
	// Label som visar användarens namn
	private JLabel userName = new JLabel("Användare");
	// Panel för scrollisten
	private JPanel activities = new JPanel();
	// Lista att lägga i JList
	private List<String> testList = new ArrayList<String>();
	// Jlist
	private JList<String> activityList = new JList<String>();
	// Panel för lägga till aktivitet-knappen
	private JPanel buttons = new JPanel();
	// Knapp för att lägga till aktivitet
	private JButton addActivity = new JButton("Lägg till aktivitet");
	private JButton changeActivity = new JButton("Ändra namn på aktivitet");
	// labels för persondata
	private JLabel name = new JLabel();
	private JLabel age = new JLabel();
	private JLabel weight = new JLabel();
	private JLabel maxPuls = new JLabel();
	// ScrollPane för listan med aktiviteter
	private JScrollPane scrollPane = new JScrollPane(activityList);	
	
	private DataView dataView;
	private GraphView graphView;
	private MapView mapView;
	
	public UserView(Controller controller, DataView dataView, GraphView graphView, MapView mapView) {
		this.controller = controller;
		this.dataView = dataView;
		this.graphView = graphView;
		this.mapView = mapView;
		setLayout(new GridLayout(1,2));
		setBackground(Color.LIGHT_GRAY);
		if(controller.getCurrentUser() != null) {
		activityList.setListData(new Vector(controller.getActivites()));
		}
		activityList.addListSelectionListener(e -> listChanged());
		
		activities.setLayout(new GridLayout(1,2));
		activities.add(scrollPane);

		addActivity.addActionListener(e -> {
			try {
				chooseFile();
			} catch (FileNotFoundException e1) {
				JOptionPane.showMessageDialog(new JOptionPane(), "Ett oväntat fel inträffade, vänligen försök igen!");
				e1.printStackTrace();
			} catch (NullPointerException e2) {
				JOptionPane.showMessageDialog(new JOptionPane(), "Ett oväntat fel inträffade, vänligen försök igen!");
				e2.printStackTrace();
			}
		});
//		changeActivity.addActionListener(e -> changeAktivityname());
		
		activities.add(addActivity);
		
		add(activities);
		buttons.setLayout(new GridLayout(7,1));
		buttons.add(userName);
		name.setText("Namn: " + controller.getCurrentUser().getName());
		buttons.add(name);
		age.setText("Ålder: " + controller.getCurrentUser().getAge());
		buttons.add(age);
		weight.setText("Vikt: " + controller.getCurrentUser().getWeight());
		buttons.add(weight);
		maxPuls.setText("Maxpuls: " + controller.getCurrentUser().getMaxPulse());
		buttons.add(maxPuls);
		buttons.add(changeActivity);
		buttons.add(addActivity);
		activities.add(buttons);
	}
	
	public void chooseFile() throws FileNotFoundException, NullPointerException {
		JFileChooser chooser = new JFileChooser();
		chooser.showOpenDialog(null);
		File file = chooser.getSelectedFile();
		String filepath = file.getAbsolutePath();
		String fileName = JOptionPane.showInputDialog("Activityname: ");
		
		controller.setFile(filepath, fileName);
		updateList();
	}
	
//	public void changeAktivityname() {
//		String fileName = JOptionPane.showInputDialog("Activityname: ");
//		controller.ChangeAktivityName(fileName);
//		updateList();
//	}
	
	public void updateList() {
		activityList.setListData(new Vector(controller.getActivites()));
	}
	
	public void listChanged() {
		String activity = String.valueOf(activityList.getSelectedValue());
		controller.setCurrentActivity(activity);
		dataView.updateView();
		graphView.updatePlot();
		mapView.updateMap();
	}
}
