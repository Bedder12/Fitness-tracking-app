package view.plot;
import java.awt.Color;
import java.awt.Graphics;
import java.util.List;

import javax.swing.JPanel;

import controller.Controller;
import model.TrackPoint;

public class MapPlotView extends JPanel {
	private Controller controller;
	private double minLat;
	private double minLong;
	private double maxLat;
	private double maxLong;
	private List<TrackPoint> trackpoints; // Ska vara en lista inte ett TrackPointobjekt

	public MapPlotView(Controller controller) {
		this.controller = controller;
	}

	public void setTrackPoints() {
		// dubbel kontroll, ha bara if på ett ställe?
		if (controller.getCurrentActivity() != null) {
			this.trackpoints = controller.getActivity();// hämta lista med trackpoint från aktivitet vid knapptryck
		}
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (controller.getCurrentActivity() != null) {
			setTrackPoints();
			findMaxMinLongLat();

			// Initialize arrays
			int[] xArray = new int[trackpoints.size()]; // trackpoints är listan med trackpoints
			int[] yArray = new int[trackpoints.size()];

			// Loopa igenom alla Trackpoints i listan
			int i = 0;
			for (TrackPoint tp : trackpoints) {
				xArray[i] = getXPixValue(tp);
				yArray[i] = getYPixValue(tp);
				i++;
			}
			g.setColor(Color.ORANGE);
			g.drawPolyline(xArray, yArray, xArray.length);
		}
	}

	// Hitta min och max long/lat för att skapa ytan att plotta i
	private void findMaxMinLongLat() {
		minLat = trackpoints.get(0).getLatitude();
		minLong = trackpoints.get(0).getLongitude();
		maxLat = trackpoints.get(trackpoints.size() - 1).getLatitude();
		maxLong = trackpoints.get(trackpoints.size() - 1).getLongitude();

		for (TrackPoint tp : trackpoints) {
			double lon = tp.getLongitude();
			double lat = tp.getLatitude();
			if (lon > maxLong) {
				maxLong = lon;
			} else if (lon < minLong) {
				minLong = lon;
			}
			if (lat > maxLat) {
				maxLat = lat;
			} else if (lat < minLat) {
				minLat = lat;
			}
		}

	}

	// Läser in Longitude från Trackpoint och gör om till lämpligt pixelvärde i
	// x-led
	private int getXPixValue(TrackPoint tp) {
		int xPix = (int) (((tp.getLongitude() - minLong) / (maxLong - minLong)) * getWidth());
		return xPix;
	}

	// Läser in Latitude från Trackpoint och gör om till lämpligt pixelvärde i y-led
	private int getYPixValue(TrackPoint tp) {
		int yPix = (int) (((tp.getLatitude() - minLat) / (maxLat - minLat)) * getHeight());
		return yPix;
	}
}