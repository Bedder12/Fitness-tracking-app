package view.plot;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Iterator;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import controller.Controller;
import model.Activity;
import model.DataFetcher;
import model.TrackPoint;

public class PlotView extends JPanel{
	private Controller controller;
	private List<TrackPoint> listaMedTrackPoints;
	private int width;
	private int height;
	private DataFetcher fetcher;
	private double totalElapsedTime;
	private double minDataValue;
	private double maxDataValue;
	private int[] xPixels;
	private int[] yPixels;
	
	public PlotView(String title, Controller controller, DataFetcher fetcher) {
		this.controller = controller;
		this.fetcher = fetcher;
		setBackground(Color.WHITE);		
		setBorder(BorderFactory.createTitledBorder(title));
	}
	
	public void setTrackPoints() {
		if(controller.getCurrentActivity() != null) {
			this.listaMedTrackPoints = controller.getTrackPointList();
		}
	}
	
	// Metod som hittar maximalt och minimalt datavärde samt den totala
	// tiden som aktiviteten pågått (sista punktens elapsed time
	private void findLimitsInData() {
		if(listaMedTrackPoints != null && listaMedTrackPoints.size() > 1) { //Fixa med nya koden
			TrackPoint firstTp = listaMedTrackPoints.get(0); // Fixa med nya koden
			TrackPoint lastTp = listaMedTrackPoints.get(listaMedTrackPoints.size()-1); //Fixa med nya koden
			minDataValue = maxDataValue = fetcher.fetch(firstTp); //min och max får samma värde
			totalElapsedTime = lastTp.getElapsedTime(); //total tid
			for(TrackPoint tp : listaMedTrackPoints) { //Loopa igenom listan med Trackpoints
				double value = fetcher.fetch(tp);	
				if(value > maxDataValue) {	//Kolla om value från tp är högre än maxData
					maxDataValue = value;
				} else if(value < minDataValue) { //Kolla om value från tp är lägre än min
					minDataValue = value;
				}
			}
		}
	}
	
	// Metod som skapar två arrayer (heltal) som ska fyllas med
	// respektive datavärde och tidsvärde, fast omräknat till det antal
	// pixlar som kan visas i x-led och det antal pixlar som kan
	// visas i y-led. Sammanfattat: anpassa mätvärdena till panelens
	// höjd och bredd och lägg de nya värdena i en x-Array och en y-array
	private void createArrays() {
		if(listaMedTrackPoints != null && listaMedTrackPoints.size() > 0) {
			findLimitsInData();
			width = getWidth();
			height = getHeight();
			yPixels = new int[width]; //borde det vara height?
			xPixels = new int[width];
			double timeStep = totalElapsedTime / width;
			double yVariation = maxDataValue - minDataValue;
			double yScale = height / yVariation;
			Iterator<TrackPoint> tpit = listaMedTrackPoints.iterator();
			if(tpit.hasNext()) {
				TrackPoint tp = tpit.next();
				for(int x = 0; x < width; x++) {
					double time = x * timeStep;
					while(tpit.hasNext() && tp.getElapsedTime() < time) {
						tp = tpit.next();
					}
					double value = fetcher.fetch(tp);
					value = value - minDataValue;
					yPixels[x] = height - (int) (0.5 + yScale * value);
					xPixels[x] = x;
				}
			}
		}
	}
	
	// Ritar upp grafen
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		setTrackPoints();
		createArrays();
		g.setColor(Color.ORANGE);
		g.drawPolyline(xPixels, yPixels, width);
	}
}
